package com.example.tranadele.todoapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

public class EditItemActivity extends AppCompatActivity {
ListView lvItems;
EditText editToDoText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        lvItems = (ListView) findViewById(R.id.lvItems);
        lvItems.setOnClickListener(new View.OnClickListener() {

    public void onClick(View v) {
        finish();
    }
});
}
}

